<div class="page_name">NEWS / BLOG</div>
<div class="col-md-12" style="padding:0px; ">
<div class="col-md-9" style="padding:0px; ">
<div class="navbar navbar-default navbar-static-top" role="navigation">
      
        <div class="navbar-header">
          <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
         
          <a class="navbar-brand" href="#"> <img src="<?php echo base_url('assets/images/logo.png'); ?>" /></a>
        </div>
        <div class="navbar-collapse collapse" style="float:right">
         
         <ul class="nav navbar-nav">
            <li class="active"><a href="#">Showcase</a></li>
            <li><a href="#about">creatives</a></li>
            <li><a href="#contact">News</a></li>
            <li><a href="#contact">Workshop</a></li>
            
          </ul>
          
        </div><!--/.nav-collapse -->
     
    </div>
</div>

<div class="col-md-3" style="padding:0px;">
	<div class="navbar navbar-default navbar-static-top" role="navigation" style="background:#2a5da8">
     
         <ul class="nav navbar-nav">
            <li><a href="#">Hi, ALDO</a></li>
          </ul>
          
         <ul class="nav navbar-nav">
            <li><a href="#" style="padding-right:0px;"><div class="circle_navbar">FB</div></a></li>
            <li><a href="#" style="padding-right:0px;"><div class="circle_navbar">TW</div></a></li>
            <li><a href="#" style="padding-right:0px;"><div class="circle_navbar">IG</div></a></li>
          </ul>
          
     
    </div>
</div>
</div>

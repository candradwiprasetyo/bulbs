<div class="col-md-12" style="padding:0px;" >
      <img src="<?= base_url(); ?>assets/images/project2.jpg" class="img_banner_project">
</div>

<div class="col-md-12">
    <div class="row">
        <div class="project_desc" style="background:#fff;">
            <div class="container">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-9">
                                <div class="profile_name">Tanamera Coffee Serpong</div>
                                <div class="profile_location">by Aldo Felix Studio</div>
                                <div class="profile_description_title">Project Info</div>
                                <div class="profile_description_content">
                                Aldo Felix Studio is a consultancy ore di culpa nonem. Cuptaque pelita veribusam volorrum vollam, nam id unturit, videatio. Lore milit voluptat arum re lam quate volum quiatis et arum harioreris a dolume remperi simet re, net lametur re
            mosandem int pro con eaquodipsus volor atum fuga. Otatet quaepel igentia nitas maionse quatqui ducidi doluptatio
            vel id etur maiores exerero rescipsandam am ra quat. Alistiis dolupta tecupta tiuntotatiae nonse doloris moluptatus
            magnia delen pro con.
                                </div>
                        </div>

                        <div class="col-md-3">
                            <div class="profile_name">&nbsp;</div>
                            <div class="profile_location">Published on May 19, 2015</div>
                            <div class="profile_description_title">Posted In Workshop</div>
                            <div class="profile_description_content">
                              
                            </div>
                        </div>

                    </div>
                </div>

                <div style="clear:both; height:30px;"></div>

                 <div class="form-group">
                     <div class="row">
                        <div class="col-md-12">
                            <img src="<?= base_url(); ?>assets/images/project2.jpg" class="img_banner_project">
                        </div>
                     </div>
                </div>

                

                 <div style="clear:both; height:50px;"></div>



            </div>
        </div>
    </div>
</div>

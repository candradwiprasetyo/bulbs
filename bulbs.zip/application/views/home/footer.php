
<div class="col-md-12" style="padding:0px; ">
<div class="col-md-9" style="padding:0px; ">
<div class="navbar navbar-default navbar-static-top" role="navigation" style="height:60px !important; min-height:60px !important; background:#2a5da8 !important">
      
        <div class="navbar-header">
          <a class="navbar-brand footer-copyright" href="#">COPYRIGHT 2015 8BULBS. ALL RIGHTS RESERVED</a>
        </div>
        <div class="navbar-collapse collapse " style="float:right">
         
         <ul class="nav navbar-nav ">
            <li><a href="#" class="footer-menu">Privacy Policy</a></li>
            <li><a href="#about" class="footer-menu">Terms of use</a></li>
            <li><a href="#contact" class="footer-menu">About us</a></li>
            
          </ul>
          
        </div><!--/.nav-collapse -->
     
    </div>
</div>

<div class="col-md-3" style="padding:0px;">
	<div class="navbar navbar-default navbar-static-top" role="navigation" style="background:#477cbd; height:60px !important; min-height:60px !important;">
     
         <a href="#"><div class="footer-icon" style="margin-left:30px;"></div></a>
         <a href="#"><div class="footer-icon"></div></a>
         <a href="#"><div class="footer-icon"></div></a>
         <a href="#"><div class="footer-icon"></div></a>
     
    </div>
</div>
</div>

<div style="clear:both;"></div>

<div class="search_page">

<div class="container" role="main">

      <!-- Main jumbotron for a primary marketing message or call to action -->
     
		<div class="row">
        	 <div class="col-md-6">
             	<div class="form-group">
                
             	<div class="search_quote">Find Creatives in Your Area</div>
               
                </div>
             </div>
             
              <div class="col-md-6">
              
             	
                	<div class="row">
                    <div class="col-md-4"> 
                    <div class="form-group">
                	<select name="i_type" size="1" class="form-control select_search new_select"/>
                                             <option value="1">Concentration</option>
                                           <option value="2">-</option>       
                                           </select>  
                                           </div>
               		 </div>
                     
                    
                	<div class="col-md-4"> 
                     <div class="form-group">
                	<select name="i_type" size="1" class="form-control select_search new_select"/>
                                             <option value="1">Location</option>
                                           <option value="2">-</option>       
                                           </select>  
                     </div>
                	</div>
                    
                     
                	<div class="col-md-4"> 
                    <div class="form-group">
                	<input class="btn button_search" type="submit" value="SEARCH"/>
                     </div>
                	</div>
                    </div>
             </div>
        
</div>

    </div> <!-- /container -->
    
</div>
<div class="container">
    <div class="row" style="margin-top:20px;">
        <div class="col-md-6">
        	<div class="form-group">
            	<div class="box_content"><img src="<?php echo base_url('assets/images/box_content.jpg'); ?>" class="box_content_img" /></div>
            </div>
            <div class="form-group" >
            	<div class="row">
                    <div class="col-xs-6"><div class="form-group" ><div class="box_content_half" style="margin-top:10px;">
                    	<img src="<?php echo base_url('assets/images/box_content2.jpg'); ?>" class="box_content_img" />
                    </div></div></div>
                    <div class="col-xs-6"><div class="form-group" ><div class="box_content_half" style="margin-top:10px;">
                    	<img src="<?php echo base_url('assets/images/box_content3.jpg'); ?>" class="box_content_img" />
                    </div></div></div>
                </div>
            </div>
        </div>
        <div class="col-md-6">
        	<div class="form-group">
        	<div class="row">
                <div class="col-xs-6"><div class="box_content_half"><img src="<?php echo base_url('assets/images/box_content2.jpg'); ?>" class="box_content_img" /></div></div>
                <div class="col-xs-6"><div class="box_content_half"><img src="<?php echo base_url('assets/images/box_content3.jpg'); ?>" class="box_content_img" /></div></div>
            </div>
            </div>
            <div class="form-group">
            <div class="row">
                <div class="col-md-12"><div class="box_content" style="margin-top:10px;"><img src="<?php echo base_url('assets/images/box_content.jpg'); ?>" class="box_content_img" /></div></div>
               
            </div>
            </div>
        </div>
    </div>
</div>
<div class="col-md-12" style="padding:0px;" >
      <div class="img_cover_image">
      	<div class="img_cover_image_content">
      	+ Add Cover Image
        </div>
      </div>
</div>

<div class="col-md-12">
    <div class="row">
        <div class="project_desc">
            <div class="container">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-9">
                                <div class="profile_name">Edit Title</div>
                                <div class="profile_location">by Aldo Felix Studio</div>
                                <div class="profile_description_title">Project Info</div>
                                <div class="profile_description_content">
                                                   Add Project Details ...
                                </div>
                        </div>

                        <div class="col-md-3">
                            <div class="profile_name">&nbsp;</div>
                            <div class="profile_location">Published on May 19, 2015</div>
                            <div class="profile_description_title">Project Concentrations</div>
                            <div class="profile_description_content">
                                <div>
                                    <label>
                                        <input type="checkbox" name="CheckboxGroup1_" value="checkbox" id="CheckboxGroup1_1" />
                                         Interior Design
                                     </label>
                              </div>
                                <div>
                                    <label>
                                        <input type="checkbox" name="CheckboxGroup1_" value="checkbox" id="CheckboxGroup1_1" />
                                         Architecture
                                     </label>
                                </div>
                                <div>
                                     <label>
                                        <input type="checkbox" name="CheckboxGroup1_" value="checkbox" id="CheckboxGroup1_1" />
                                         Graphic Design
                                     </label>
                                </div>
                                
                             
                                
                            </div>
                        </div>

                    </div>
                </div>
				
                <div style="clear:both; height:30px;"></div>
				
                <div class="img_add_image">
                    <div class="img_add_image_content">
                    + Add Image
                    </div>
                 </div>
                
                 <div style="clear:both; height:50px;"></div>
            </div>
        </div>
    </div>
</div>
<?php
/**/
// homepage
include 'homepage/navbar.php';
include 'homepage/slider.php';
include 'homepage/search.php';
include 'homepage/gallery.php';
include 'footer.php';

// login page
include 'login/navbar.php';
include 'login/login_form.php';
include 'footer.php';

// showcase
include 'showcase/navbar.php';
include 'showcase/index.php';
include 'footer.php';



// profile
include 'profile/navbar.php';
include 'profile/index.php';
include 'footer.php';

// project
include 'project/navbar.php';
include 'project/index.php';
include 'footer.php';

// talent dashboard
include 'talent_dashboard/navbar.php';
include 'talent_dashboard/index.php';
include 'footer.php';

// talent dashboard 2 / following
include 'talent_dashboard/navbar.php';
include 'talent_dashboard/following.php';
include 'footer.php';

// talent dashboard 3 / cover image
include 'talent_dashboard/navbar.php';
include 'talent_dashboard/cover_image.php';
include 'footer.php';

// seeker dashboard
include 'seeker_dashboard/navbar.php';
include 'seeker_dashboard/index.php';
include 'footer.php';

// seeker dashboard 2 / 
include 'seeker_dashboard/navbar.php';
include 'seeker_dashboard/index.php';
include 'footer.php';

// news
include 'news/navbar.php';
include 'news/index.php';
include 'footer.php';

// news 2 / blog post
include 'news/navbar.php';
include 'news/blog_post.php';
include 'footer.php';


?>


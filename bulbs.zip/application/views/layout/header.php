<!DOCTYPE html>
<html lang="en"><head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title><?= $title ?></title>

    <!-- Bootstrap core CSS -->
    <link href="<?= base_url('assets/css/bootstrap.min.css') ?>" rel="stylesheet">
    <!-- Bootstrap theme -->
    <link href="<?= base_url('assets/css/bootstrap-theme.min.css') ?>" rel="stylesheet">
	<!-- My Style -->
	<link href="<?= base_url('assets/css/style.css') ?>" rel="stylesheet">
    <!-- showcase-->
    <link href="<?= base_url('assets/css/showcase/demo.css') ?>" rel="stylesheet">
    <link href="<?= base_url('assets/css/showcase/component.css') ?>" rel="stylesheet">
    <!-- slider -->
    <link href="<?= base_url('assets/css/slider/slider.css') ?>" rel="stylesheet">
  	<script type="text/javascript" src="<?= base_url('assets/js/slider/jquery-1.9.1.min.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('assets/js/slider/jssor.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('assets/js/slider/jssor.slider.js') ?>"></script>
    <script type="text/javascript" src="<?= base_url('assets/js/slider/slider.js') ?>"></script>
    
  </head>

  <body role="document">
  
  

   
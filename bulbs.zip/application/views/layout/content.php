<?php
if ( ! defined('BASEPATH')) exit('No direct script access allowed');
if($isi){
 	$this->load->view($isi);
}
?>
   
<style type="text/css">
.title {
	text-align: center;
	font-weight: bold;
}
</style>
<p class="title">Reset Password</p>

<p>Anda meminta untuk mengganti password. Bila ternyata Anda tidak meminta ini, harap abaikan.</p>
<p>Jika Anda memang ingin mereset password, klik link berikut: </p>
<p>http://www.8bulbs.co/forgot/form_reset_password/<?= $user_id ?>/<?= $new_password ?></p>

<p>Saat Agan mengunjungi link tersebut, silahkan memasukkan password baru.
<p></p>
<p>Terima Kasih,</p>
<p>
8bulbs.co </p>


<div class="icon_home_page">
<div class="container">
    <div class="row">
   		 <div class="col-md-12">
                                            	<div class="new_title">HIRE CREATIVE MINDS EASIER THAN EVER</div>
                                            </div>
        <div class="col-md-4" style="text-align:center">
        	<img src="<?= base_url() ?>assets/images/icon_home/icon1.png" class="icon_home_img" >
            <div class="icon_home_title">CONNECT</div>
            <div class="icon_home_desc">Directly hire or collaborate with hundreds of
reliable creative professionals easier and faster.</div>
        </div>
        
       <div class="col-md-4" style="text-align:center">
        	<img src="<?= base_url() ?>assets/images/icon_home/icon2.png" class="icon_home_img"  >
            <div class="icon_home_title">INSPIRE
</div>
            <div class="icon_home_desc">Publish creative portfolios and inspire other
professionals in the same or different industry.</div>
        </div>
        
        <div class="col-md-4" style="text-align:center">
        	<img src="<?= base_url() ?>assets/images/icon_home/icon3.png" class="icon_home_img"  >
            <div class="icon_home_title">TRUST
</div>
            <div class="icon_home_desc">Get trusted reviews of all creative
professionals from previous clients.</div>
        </div>
    </div>
</div>
            	
</div>
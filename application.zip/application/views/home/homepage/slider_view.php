<div class="col-md-12" style="padding:0px;" >
      <img src="<?= base_url(); ?>assets/images/slider/<?= $slider_img ?>" class="img_banner_project">
</div>

<div class="col-md-12">
    <div class="row">
        <div class="project_desc" style="background:#fff;">
            <div class="container">
                <div class="col-md-12">
                    <div class="row">
                        <div class="col-md-12">
                                <div class="profile_name"><?= $slider_name ?></div>
                                <div class="profile_location"></div>
                                <div class="profile_description_content">
                               <?= $slider_desc ?>
                                </div>
                                 <a href="javascript: history.back()" class="btn btn-primary">Back</a>
                        </div>

                       

                    </div>
                </div>

                <div style="clear:both; height:30px;"></div>
				<!--
                 <div class="form-group">
                     <div class="row">
                        <div class="col-md-12">
                            <img src="<?= base_url(); ?>assets/images/project2.jpg" class="img_banner_project">
                        </div>
                     </div>
                </div>

                -->

                 <div style="clear:both; height:50px;"></div>



            </div>
        </div>
    </div>
</div>

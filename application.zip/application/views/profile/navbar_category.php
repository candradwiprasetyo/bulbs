<div class="col-md-9">
       	 	<div class="row">
                 <div class="navbar_category">
                 	<div class="container">
                    	<div class="navbar_category_menu">&nbsp;</div>
                        <div class="navbar_category_menu"><a href="<?=site_url('profile'); ?>">Profile</a></div>
                        <div class="navbar_category_menu"><a href="<?=site_url('follower'); ?>">Followers</a></div>
                        <div class="navbar_category_menu"><a href="<?=site_url('following'); ?>">Followings</a></div>
                     	<div class="navbar_category_menu"><a href="<?=site_url('project/add'); ?>">Upload Work</a></div>
                        <div class="navbar_category_menu"><a href="<?=site_url('message/view'); ?>">Message</a></div>
                    </div>
                 </div>
             </div> 
        </div>
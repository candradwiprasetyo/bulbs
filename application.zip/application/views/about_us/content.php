

<div class="about_us_page">

<div class="container">
    <div class="row">
   		 <div class="col-md-12">
                                            	<div class="new_title">About 8Bulbs</div>
                                                <div class="icon_home_desc">We aim to eradicate the old, time-consuming ways of finding<br />
the creative professionals you need.</div><br />
                                            </div>
        <div class="col-md-3" style="text-align:center">
        	<img src="<?= base_url() ?>assets/images/about_us/1.png" class="icon_home_img" >
            
            <div class="about_us_desc">To connect seekers and talent
directly</div>
        </div>
        
       <div class="col-md-3" style="text-align:center">
        	<img src="<?= base_url() ?>assets/images/about_us/2.png" class="icon_home_img"  >
          
            <div class="about_us_desc">To empower creatives and artists to
showcase their works</div>
        </div>
        
        <div class="col-md-3" style="text-align:center">
        	<img src="<?= base_url() ?>assets/images/about_us/3.png" class="icon_home_img"  >
           
            <div class="about_us_desc">Get trusted reviews of all creative
professionals from previous clients.</div>
        </div>
        
        <div class="col-md-3" style="text-align:center">
        	<img src="<?= base_url() ?>assets/images/about_us/4.png" class="icon_home_img"  >
           
            <div class="about_us_desc">To convert ideas into reality</div>
        </div>
    </div>
</div>

<div class="about_us_banner">
    <div class="about_us_page_banner"></div>
<div class="container">
We've created a platform to boost Indonesia's creative industries.<br />
This core purpose is the motivation behind who we are,<br />
and why we come to work everyday.
</div>
</div>

<div class="about_us_banner2">
<div class="container">
We will keep developing our platform to give more<br />
and more benefits for both creatives and seekers.<br />
And we'll make it better every time.<br />
There is no limit to what we will do.
</div>
</div>

<div class="icon_home_title">CONNECT. INSPIRE. TRUST.</div>
            	
</div>